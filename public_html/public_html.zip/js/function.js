function Pokemon(name, image, weight) {
    this.name = name,
    this.image = image,
    this.weight = weight;
}

$("input").keypress(function (e) {

    e.preventDefault;
    if (e.which === 13) {
        index = ($("#callPokemon").val());
        $("input").select();
        $("input").val("");

        if (index <= 721 || "") {
            url = "http://pokeapi.co/api/v2/pokemon/" + index + "/";
            $("ul").append($.get);

            $.get("http://pokeapi.co/api/v2/pokemon/" + index + "/", function (data) {
                $(".result").html(data);
                $("ul").append("<li><h2>" + data.forms[0].name + "</h2></li>");
                $("ul").append("<li>Tipo: " + data.types[0].type.name /*+ ", " + data.types[1].type.name*/ + " </li>");
                $("ul").append("<li><img src =" + data.sprites.front_default + "></img</li>");
                $("ul").append("<li>Peso: " + data.weight + " </li>");
                $("ul").append("<li>Altura: " + data.height + " </li>");
            });

        } else {
            alert("Ese pokemon no está en la lista");
        }
        return url;
    };
});

//$.get( "http://pokeapi.co/api/v2/pokemon/1/", function( data ) {
//  $( ".result" ).html( data );
//  document.write("El pokemon es " + data.forms[0].name + "\n");
//  document.write(data.sprites.front_default);
//  document.write("Descripción " + data.weight);
//});